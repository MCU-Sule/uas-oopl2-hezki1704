/**
 * @author 1972004 - Yehezkiel Christian
 */


package com.example.uas_pbo2_1972004.Util;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HibernateUtil {
    public static Session getSession(){
        SessionFactory sessionFactory;
        sessionFactory = new Configuration().configure().buildSessionFactory();
        Session session;
        session = sessionFactory.openSession();
        return  session;
    }
}
