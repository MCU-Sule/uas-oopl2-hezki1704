package com.example.uas_pbo2_1972004;

import com.example.uas_pbo2_1972004.DAO.MemberDAO;
import com.example.uas_pbo2_1972004.DAO.PointDAO;
import com.example.uas_pbo2_1972004.DAO.TransactionDAO;
import com.example.uas_pbo2_1972004.Model.FeMemberEntity;
import com.example.uas_pbo2_1972004.Model.FePointEntity;
import com.example.uas_pbo2_1972004.Model.FeTransactionEntity;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;

import java.net.URL;
import java.sql.Date;
import java.util.ResourceBundle;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainController implements Initializable {
    @FXML
    private TextField txt1;
    @FXML
    private TextField txt2;
    @FXML
    private TextField txt3;
    @FXML
    private TextField txt4;
    @FXML
    private TextField txt5;
    @FXML
    private TextField txt6;
    @FXML
    private TextArea txta1;
    @FXML
    private DatePicker date1;
    @FXML
    private DatePicker date2;
    @FXML
    private Button btnSave;
    @FXML
    private Button btnUpdate;
    @FXML
    private Button btnReset;
    @FXML
    private TableView<FeMemberEntity> table1;
    @FXML
    private TableView<FeTransactionEntity> table2;
    @FXML
    private TableView<FePointEntity> table3;
    @FXML
    private TableColumn<FeMemberEntity,String>col1;
    @FXML
    private TableColumn<FeMemberEntity,String>col2;
    @FXML
    private TableColumn<FeMemberEntity,String>col3;
    @FXML
    private TableColumn<FeMemberEntity,String>col4;
    @FXML
    private TableColumn<FeTransactionEntity,String>col5;
    @FXML
    private TableColumn<FeTransactionEntity,String>col6;
    @FXML
    private TableColumn<FePointEntity,String>col7;
    @FXML
    private TableColumn<FePointEntity,String>col8;
    @FXML
    private Label lbl1;



    private ObservableList<FeMemberEntity>members;
    private ObservableList<FeTransactionEntity>transactions;
    private ObservableList<FePointEntity>points;
    private LoginController lc;

    public void saveMemberAction(ActionEvent actionEvent) {
        Task<Void> task = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                FeMemberEntity member = new FeMemberEntity();
                member.setCitizenId(txt1.getText());
                member.setName(txt2.getText());
                member.setAddress(txt3.getText());
                member.setBirthdate(Date.valueOf(date1.getValue()));
                MemberDAO memberdao = new MemberDAO();
                memberdao.addData(member);
                members.clear();
                members.addAll(memberdao.showData());
                table1.refresh();
                return null;
            }
        };
        ExecutorService service = Executors.newCachedThreadPool();
        service.execute(task);
        service.shutdown();
    }

    public void resetAction(ActionEvent actionEvent) {
        txt1.clear();
        txt2.clear();
        txt3.clear();
        txt4.clear();
        txt5.clear();
        txt6.clear();
        txta1.clear();
        btnSave.setDisable(false);
        btnUpdate.setDisable(true);

    }

    public void updateAction(ActionEvent actionEvent) {
        Task<Void> task = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                FeMemberEntity selected = table1.getSelectionModel().getSelectedItem();
                selected.setCitizenId(txt1.getText());
                selected.setName(txt2.getText());
                selected.setAddress(txta1.getText());
                selected.setPhone(txt3.getText());
                selected.setEmail(txt4.getText());
                selected.setUsername(txt5.getText());
                selected.setBirthdate(Date.valueOf(date1.getValue()));
                MemberDAO memberdao = new MemberDAO();
                memberdao.updateData(selected);
                members.clear();
                members.addAll(memberdao.showData());
                table1.refresh();
                btnSave.setDisable(false);
                btnUpdate.setDisable(true);
                return null;
            }
        };
        ExecutorService service = Executors.newCachedThreadPool();
        service.execute(task);
        service.shutdown();
    }

    public void saveTransAction(ActionEvent actionEvent) {
        Task<Void> task = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                FeTransactionEntity transaction = new FeTransactionEntity();
                transaction.setNominal(Long.parseLong(txt6.getText()));
                transaction.setTransDate(Date.valueOf(date2.getValue()));
                TransactionDAO transactiondao = new TransactionDAO();
                transactiondao.addData(transaction);
                transactions.clear();
                transactions.addAll(transactiondao.showData());
                table2.refresh();
                return null;
            }
        };
        ExecutorService service = Executors.newCachedThreadPool();
        service.execute(task);
        service.shutdown();
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        Task<Void> task = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                MemberDAO md = new MemberDAO();
                PointDAO pd = new PointDAO();
                TransactionDAO td = new TransactionDAO();
                members = (ObservableList<FeMemberEntity>) md.showData();
                points =(ObservableList<FePointEntity>) pd.showData();
                transactions =(ObservableList<FeTransactionEntity>) td.showData();
                table1.setItems(members);
                table2.setItems(transactions);
                table3.setItems(points);
                col1.setCellValueFactory(data-> new SimpleStringProperty(String.valueOf(data.getValue().getCitizenId())));
                col2.setCellValueFactory(data-> new SimpleStringProperty(data.getValue().getName()));
                col3.setCellValueFactory(data-> new SimpleStringProperty(data.getValue().getPhone()));
                col4.setCellValueFactory(data-> new SimpleStringProperty(String.valueOf(data.getValue().getBirthdate())));
                col5.setCellValueFactory(data-> new SimpleStringProperty(String.valueOf(data.getValue().getTransDate())));
                col6.setCellValueFactory(data-> new SimpleStringProperty(String.valueOf(data.getValue().getNominal())));
                col7.setCellValueFactory(data-> new SimpleStringProperty(String.valueOf(data.getValue().getId())));
                col8.setCellValueFactory(data-> new SimpleStringProperty(String.valueOf(data.getValue().getValue())));
                return null;
            }
        };
        ExecutorService service = Executors.newCachedThreadPool();
        service.execute(task);
        service.shutdown();
    }

    public void memberClicked(MouseEvent mouseEvent) {
        FeMemberEntity selected = table1.getSelectionModel().getSelectedItem();
        txt1.setText(String.valueOf(selected.getCitizenId()));
        txt2.setText(String.valueOf(selected.getName()));
        txt3.setText(selected.getPhone());
        txt4.setText(selected.getEmail());
        txt5.setText(selected.getUsername());
        txta1.setText(selected.getAddress());
        btnSave.setDisable(true);
        btnUpdate.setDisable(false);

    }

    public void setController (LoginController lc){
        this.lc = lc;
    }
}