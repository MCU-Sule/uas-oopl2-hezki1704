package com.example.uas_pbo2_1972004.DAO;

import com.example.uas_pbo2_1972004.Model.FePointEntity;
import com.example.uas_pbo2_1972004.Model.FeTransactionEntity;
import com.example.uas_pbo2_1972004.Util.HibernateUtil;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import org.hibernate.Session;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import java.util.List;

public class PointDAO implements daointerface<FePointEntity>{
    @Override
    public int addData(FePointEntity data) {
        return 0;
    }

    @Override
    public int delData(FePointEntity data) {
        return 0;
    }

    @Override
    public int updateData(FePointEntity data) {
        return 0;
    }

    @Override
    public ObservableList<FePointEntity> showData() {
        Session s = HibernateUtil.getSession();
        CriteriaBuilder builder = s.getCriteriaBuilder();
        CriteriaQuery query = builder.createQuery(FePointEntity.class);

        query.from(FePointEntity.class);

        List<FePointEntity> clist = s.createQuery(query).getResultList();
        s.close();

        return FXCollections.observableArrayList(clist);
    }
}
