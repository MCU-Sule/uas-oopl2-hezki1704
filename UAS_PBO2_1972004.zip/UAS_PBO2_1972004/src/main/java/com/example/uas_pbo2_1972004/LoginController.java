package com.example.uas_pbo2_1972004;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import java.io.IOException;

public class LoginController {
    @FXML
    private TextField txt1;
    @FXML
    private TextField txt2;
    @FXML
    private Button btnLogin;

    public void loginAction(ActionEvent actionEvent) throws IOException {
        if (txt1.getText().equals( "1972004" ) && txt2.getText().equals("Yehezkiel123")) {
            Stage new_stage = new Stage();
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("main-view.fxml"));
            Parent root = fxmlLoader.load();
            MainController mc = fxmlLoader.getController();
            mc.setController(this);

            Scene new_scene = new Scene(root);
            new_stage.setScene(new_scene);
            new_stage.initModality(Modality.WINDOW_MODAL);
            new_stage.setTitle("Main Form");
            new_stage.show();
        }
    }
}
