/**
 * @author 1972004 - Yehezkiel Christian
 */

package com.example.uas_pbo2_1972004.DAO;

import java.util.List;

public interface daointerface<E> {
    public int addData(E data);
    public int delData (E data);
    public int updateData (E data);
    public List<E> showData();
}
